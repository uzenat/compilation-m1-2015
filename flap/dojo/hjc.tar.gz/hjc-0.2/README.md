hjc
===

Command-line client for Hackojo

# Dependencies

OCaml (>= 4.00), curl, ocamlnet, yojson.

To install dependencies:
```
apt-get install curl
opam install ocamlnet yojson
```

# Compilation

```
./configure && make
```