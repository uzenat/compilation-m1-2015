type exp =
  | Int of int
  | Add of exp * exp
  | Sub of exp * exp
  | Mul of exp * exp

let rec make_large_tree n =
  if n = 1 then
    Int 1
  else
    let a = make_large_tree (n - 1) in
    Add (a, a)

let rec eval = function
  | Int x -> x
  | Add (a, b) -> eval a + eval b
  | Sub (a, b) -> eval a - eval b
  | Mul (a, b) -> eval a * eval b

let main =
  let nb_test = int_of_string Sys.argv.(1) in
  let depth = int_of_string Sys.argv.(2) in
  let accu = ref 0 in
  for i = 0 to nb_test - 1 do
    accu := !accu + eval (make_large_tree depth);
  done;
  Printf.printf "%d\n%!" !accu
