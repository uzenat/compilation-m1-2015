/* Stairway

   Donald connaît le C mieux que vous: non seulement il maîtrise la
   syntaxe des pointeurs sur fonction mais il sait aussi que les
   fonctions imbriquées sont acceptés par le compilateur GNU C...  Il
   vous montre un premier test (voir la fonction test1) qui semble
   effectivement fonctionner.

   Cependant, ce n'est pas suffisant pour traiter les fonctions
   sérieusement! C'est ce que montre le second test (voir la fonction
   test2).

   Les commentaires de Donald sont écrits en anglais dans la suite.

*/

#include <stdio.h>
#include <stdlib.h>

/* This is the type for functions from int to int. Why would it have to 
   be more complex than that!? */
typedef int (*initializer_t) (int);

/* Array.init implemented in C. */
int* init (int size, initializer_t init_function) {
  int* array = (int*) malloc (sizeof (int) * size);
  for (unsigned int i = 0; i < size; i++)
    array[i] = init_function (i);
  return array;
}

/* Hey look! This is how I implement your function "range". */
int* simple_range (int start, int stop) {
  int initialize (int i) {
    return (i + start);
  }
  return (init (stop - start + 1, initialize));
}

/* A function to see something on the terminal. */
void show_array (unsigned int size, int* a) {
  for (unsigned int i = 0; i < size; i++) {
    printf ("%d ", a[i]);
  }
  printf ("\n");
}

/* ... and this is "range 0 10"! */
void test1 () {
  show_array (10, simple_range (0, 10));
}

/* Hmm, you want to partially apply "range"? The following
   should work: */

typedef int* (*range_return_t) (int);

range_return_t range (int start) {
  int initialize (int i) {
    return (i + start);
  }
  int* make (int stop) {
    return (init (stop - start + 1, initialize));
  }
  return make;
}

/* Of course, there is no polymorphism in C because C programmers are
   not afraid of writing the same code over and over since they do not
   introduce bugs in their programs. Here is a version of "init" for
   arrays of arrays. */
typedef int* (*initializer2_t) (int);

int** init2 (int size, initializer2_t init_function) {
  int** array = (int**) malloc (sizeof (int*) * size);
  for (unsigned int i = 0; i < size; i++)
    array[i] = init_function (i);
  return array;
}

/* Now, let us test this code! This is the equivalent of

   let stairs = init 10 (range 0)

   , right?
*/
void test2 () {
  int** stairs = init2 (10, range (0));
  for (unsigned i = 0; i < 10; i++) {
    for (unsigned j = 0; j <= i; i++) {
      printf ("%d ", stairs[i][j]);
    }
    printf ("\n");
  }
}

int main (int argc, char** argv) {
  test1 ();
  // test2 ();
  exit (EXIT_SUCCESS);
}
